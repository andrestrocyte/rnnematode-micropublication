#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Rebuild figures, tables, LaTeX sources, PDFs, and contribution files.
./build.sh

# Execute the lightweight explanatory notebooks in-place.
for nb in Codes/*.ipynb; do
  jupyter nbconvert --to notebook --execute --inplace "$nb"
done
