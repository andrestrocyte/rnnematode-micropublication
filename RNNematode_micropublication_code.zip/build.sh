#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python scripts/build_micropublication_assets.py
latexmk -pdf -interaction=nonstopmode RNNematode-Micropublication.tex
latexmk -c RNNematode-Micropublication.tex >/dev/null 2>&1 || true
cd report
latexmk -pdf -interaction=nonstopmode RNNematode-TechnicalReport.tex
latexmk -c RNNematode-TechnicalReport.tex >/dev/null 2>&1 || true
