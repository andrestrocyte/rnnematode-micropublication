#!/usr/bin/env python3
"""Build the RNNematode Neuromatch micropublication package from saved results.

This script intentionally does not run training.  It reads the checked result
artifacts from the SC-NCAP / teacher-guided cerebellum experiments, validates
the key tables, and writes a compact micropublication envelope: figures, LaTeX
sources, notebooks, contribution files, and a longer technical report.
"""

from __future__ import annotations

import json
import math
import re
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import nbformat as nbf
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill


ROOT = Path(__file__).resolve().parents[3]
PKG = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "paper" / "experiments" / "sc_ncap" / "results"
NEURIPS = ROOT / "paper" / "neurips_2026"

HUM20 = RESULTS / "humanoid_teacher_guided_20seed_campaign" / "20260421_rerun" / "analysis"
MORPH = RESULTS / "morphology_scaling" / "20260219_153942" / "analysis"

FIG_DIR = PKG / "Figures"
TABLE_DIR = PKG / "derived_tables"
CODE_DIR = PKG / "Codes"
REPORT_DIR = PKG / "report"
VIDEO_INDEX_DIR = PKG / "video_index"


@dataclass(frozen=True)
class Paths:
    humanoid_summary: Path = HUM20 / "humanoid_consolidation_default_summary.csv"
    humanoid_method_stats: Path = HUM20 / "humanoid_consolidation_default_method_stats.csv"
    humanoid_allseeds: Path = HUM20 / "humanoid_consolidation_default_allseeds.csv"
    cross_env: Path = NEURIPS / "tables" / "cross_env_summary.csv"
    failure_ladder: Path = NEURIPS / "tables" / "failure_ladder_effectsizes.csv"
    teacher_quality: Path = NEURIPS / "tables" / "teacher_degradation_replication_summary.csv"
    morphology: Path = MORPH / "morphology_vs_benefit.csv"
    morphology_stats: Path = MORPH / "morphology_scaling_stats.json"
    video_index: Path = RESULTS / "representative_videos" / "20260422_000426" / "curated" / "representative_video_index.csv"


P = Paths()


def _mkdirs() -> None:
    for d in [FIG_DIR, TABLE_DIR, CODE_DIR, REPORT_DIR, VIDEO_INDEX_DIR, PKG / "tables"]:
        d.mkdir(parents=True, exist_ok=True)


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def _relativize_known_paths(text: str) -> str:
    """Remove machine-specific paths from packaged CSV/JSON artifacts."""
    replacements = {
        str(ROOT) + "/paper/micropublication_rnnematode/": "",
        str(ROOT) + "/paper/experiments/sc_ncap/results/representative_videos/": "videos/",
        str(ROOT) + "/paper/experiments/sc_ncap/results/": "archived_results/",
        str(ROOT) + "/": "",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def _write_packaged_video_index() -> None:
    if not P.video_index.exists():
        return
    vdf = pd.read_csv(P.video_index)
    for col in ["source_path", "curated_path"]:
        if col in vdf.columns:
            vdf[col] = vdf[col].astype(str).map(_relativize_known_paths)
    vdf.to_csv(VIDEO_INDEX_DIR / "representative_video_index.csv", index=False)


def _metric_row(df: pd.DataFrame, comparison: str, metric: str, sweep: str) -> pd.Series:
    row = df[(df["comparison"] == comparison) & (df["metric"] == metric) & (df["sweep_type"] == sweep)]
    if row.empty:
        raise KeyError((comparison, metric, sweep))
    return row.iloc[0]


def _latex_escape(text: str) -> str:
    repl = {
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
        "\\": r"\textbackslash{}",
    }
    return "".join(repl.get(ch, ch) for ch in str(text))


def _savefig(fig: plt.Figure, stem: str) -> None:
    for ext in ["png", "pdf", "svg"]:
        fig.savefig(FIG_DIR / f"{stem}.{ext}", bbox_inches="tight", dpi=220)
    plt.close(fig)


def _ci_err_for_delta(row: pd.Series, sign: float = 1.0) -> Tuple[float, float]:
    mean = sign * float(row["mean"])
    low = min(sign * float(row["ci_low"]), sign * float(row["ci_high"]))
    high = max(sign * float(row["ci_low"]), sign * float(row["ci_high"]))
    return mean - low, high - mean


def _copy_reference_bib() -> None:
    src = NEURIPS / "references.bib"
    text = src.read_text()
    extra = r"""

@misc{schulman2017ppo,
  title = {Proximal Policy Optimization Algorithms},
  author = {John Schulman and Filip Wolski and Prafulla Dhariwal and Alec Radford and Oleg Klimov},
  year = {2017},
  eprint = {1707.06347},
  archivePrefix = {arXiv},
  primaryClass = {cs.LG},
  url = {https://arxiv.org/abs/1707.06347}
}

@inproceedings{todorov2012mujoco,
  title = {{MuJoCo}: A Physics Engine for Model-Based Control},
  author = {Emanuel Todorov and Tom Erez and Yuval Tassa},
  booktitle = {2012 IEEE/RSJ International Conference on Intelligent Robots and Systems},
  pages = {5026--5033},
  year = {2012},
  doi = {10.1109/IROS.2012.6386109}
}

@misc{brockman2016openai,
  title = {{OpenAI Gym}},
  author = {Greg Brockman and Vicki Cheung and Ludwig Pettersson and Jonas Schneider and John Schulman and Jie Tang and Wojciech Zaremba},
  year = {2016},
  eprint = {1606.01540},
  archivePrefix = {arXiv},
  primaryClass = {cs.LG},
  url = {https://arxiv.org/abs/1606.01540}
}
"""
    if "schulman2017ppo" not in text:
        text = text.rstrip() + "\n" + extra
    (PKG / "references.bib").write_text(text)


def build_derived_tables() -> Dict[str, object]:
    hs = _read_csv(P.humanoid_summary)
    hm = _read_csv(P.humanoid_method_stats)
    ce = _read_csv(P.cross_env)
    fail = _read_csv(P.failure_ladder)
    tq = _read_csv(P.teacher_quality)
    morph = _read_csv(P.morphology)

    selected = hs[
        hs["comparison"].isin(["imitation_on_minus_off", "consolidated_minus_baseline"])
        & hs["metric"].isin(["fall", "return", "recovery"])
        & hs["sweep_type"].isin(["push", "sensor", "slip"])
    ].copy()
    selected.to_csv(TABLE_DIR / "humanoid20_key_results.csv", index=False)
    hm.to_csv(TABLE_DIR / "humanoid20_method_stats.csv", index=False)

    # Make a compact cross-environment table.  Replace the old Humanoid N=3
    # row with the N=20 default-schedule Humanoid estimate for this package.
    rows = []
    for source in ["imitation_on_minus_off", "consolidated_minus_baseline"]:
        for metric in ["fall", "return"]:
            vals = hs[(hs["comparison"] == source) & (hs["metric"] == metric)]
            rows.append(
                {
                    "env": "Humanoid-v4",
                    "source": source,
                    "metric": metric,
                    "mean": float(vals["mean"].mean()),
                    "sem": float(vals["sem"].mean()),
                    "n": 20,
                    "note": "Humanoid default predefined severity sweep, N=20",
                }
            )
    ce_no_hum = ce[ce["env"] != "Humanoid-v4"].copy()
    ce_no_hum["n"] = 3
    ce_no_hum["note"] = "Cross-environment replication summary"
    ce_micro = pd.concat([ce_no_hum, pd.DataFrame(rows)], ignore_index=True)
    ce_micro.to_csv(TABLE_DIR / "cross_environment_summary_micropublication.csv", index=False)

    fail_fall = fail[(fail["metric"] == "fall") & (fail["sweep_type"].isin(["push", "sensor", "slip"]))].copy()
    fail_fall.to_csv(TABLE_DIR / "rl_only_failure_ladder_fall.csv", index=False)
    tq.to_csv(TABLE_DIR / "teacher_quality_replication_summary.csv", index=False)
    morph.to_csv(TABLE_DIR / "morphology_vs_benefit.csv", index=False)

    # Friendly LaTeX tables for the report.
    main_table = selected[
        (selected["comparison"].isin(["imitation_on_minus_off", "consolidated_minus_baseline"]))
        & (selected["metric"].isin(["fall", "return"]))
    ][["comparison", "sweep_type", "metric", "mean", "sem", "ci_low", "ci_high", "n_seeds"]].copy()
    main_table["mean"] = main_table["mean"].map(lambda x: f"{x:.3f}")
    main_table["sem"] = main_table["sem"].map(lambda x: f"{x:.3f}")
    main_table["ci"] = [
        f"[{float(lo):.3f}, {float(hi):.3f}]"
        for lo, hi in zip(main_table["ci_low"], main_table["ci_high"])
    ]
    main_table = main_table.drop(columns=["ci_low", "ci_high"])
    (PKG / "tables" / "humanoid_key_results.tex").write_text(
        main_table.to_latex(index=False, escape=True)
    )

    cross_table = ce_micro[ce_micro["metric"].isin(["fall", "return"])].copy()
    cross_table = cross_table[["env", "source", "metric", "mean", "sem", "n"]]
    cross_table["mean"] = cross_table["mean"].map(lambda x: f"{x:.3f}")
    cross_table["sem"] = cross_table["sem"].map(lambda x: f"{x:.3f}")
    (PKG / "tables" / "cross_environment_summary.tex").write_text(
        cross_table.to_latex(index=False, escape=True)
    )

    teacher_table = tq[
        tq["teacher_variant"].isin(["T_full", "T_weak"])
    ][
        [
            "teacher_variant",
            "sweep_type",
            "n_seeds",
            "delta_auc_fall_mean",
            "delta_auc_fall_ci_low",
            "delta_auc_fall_ci_high",
            "delta_auc_return_mean",
        ]
    ].copy()
    teacher_table["fall_delta_ci"] = [
        f"{float(m):.3f} [{float(lo):.3f}, {float(hi):.3f}]"
        for m, lo, hi in zip(
            teacher_table["delta_auc_fall_mean"],
            teacher_table["delta_auc_fall_ci_low"],
            teacher_table["delta_auc_fall_ci_high"],
        )
    ]
    teacher_table["return_delta"] = teacher_table["delta_auc_return_mean"].map(lambda x: f"{x:.1f}")
    teacher_table = teacher_table[["teacher_variant", "sweep_type", "n_seeds", "fall_delta_ci", "return_delta"]]
    (PKG / "tables" / "teacher_quality_short.tex").write_text(
        teacher_table.to_latex(index=False, escape=True)
    )

    morph_table = morph[
        [
            "env_id",
            "n_actuated_joints",
            "total_dof",
            "max_simultaneous_contacts",
            "mean_fall_auc_delta_imitation_on_off",
            "mean_fall_auc_delta_consolidated_minus_baseline",
        ]
    ].copy()
    for col in [
        "mean_fall_auc_delta_imitation_on_off",
        "mean_fall_auc_delta_consolidated_minus_baseline",
    ]:
        morph_table[col] = morph_table[col].map(lambda x: f"{x:.3f}")
    morph_table = morph_table.rename(
        columns={
            "env_id": "env",
            "n_actuated_joints": "joints",
            "total_dof": "dof",
            "max_simultaneous_contacts": "contacts",
            "mean_fall_auc_delta_imitation_on_off": "imit fall delta",
            "mean_fall_auc_delta_consolidated_minus_baseline": "cons fall delta",
        }
    )
    (PKG / "tables" / "morphology_short.tex").write_text(
        morph_table.to_latex(index=False, escape=True)
    )

    _write_packaged_video_index()
    validations = validate_inputs(hs, hm, ce_micro, fail_fall, tq)
    for artifact in list(TABLE_DIR.glob("*.csv")) + list(TABLE_DIR.glob("*.json")):
        artifact.write_text(_relativize_known_paths(artifact.read_text()))
    return {
        "humanoid_summary": hs,
        "humanoid_method_stats": hm,
        "cross_env_micro": ce_micro,
        "failure_fall": fail_fall,
        "teacher_quality": tq,
        "morphology": morph,
        "validations": validations,
    }


def validate_inputs(
    hs: pd.DataFrame,
    hm: pd.DataFrame,
    ce_micro: pd.DataFrame,
    fail_fall: pd.DataFrame,
    tq: pd.DataFrame,
) -> Dict[str, object]:
    validation: Dict[str, object] = {}

    validation["humanoid20_all_key_rows_n20"] = bool(
        (hs[hs["comparison"].isin(["imitation_on_minus_off", "consolidated_minus_baseline"])]["n_seeds"] == 20).all()
    )
    validation["humanoid20_imitation_fall_ci_excludes_zero"] = {}
    validation["humanoid20_consolidated_fall_ci_excludes_zero"] = {}
    for sweep in ["push", "sensor", "slip"]:
        r = _metric_row(hs, "imitation_on_minus_off", "fall", sweep)
        validation["humanoid20_imitation_fall_ci_excludes_zero"][sweep] = bool(r["ci_high"] < 0)
        r2 = _metric_row(hs, "consolidated_minus_baseline", "fall", sweep)
        validation["humanoid20_consolidated_fall_ci_excludes_zero"][sweep] = bool(r2["ci_high"] < 0)

    sanity = {}
    for env in ["humanoid", "walker2d", "ant", "hopper"]:
        p = RESULTS / f"{env}_perturbation_sanity_summary.json"
        if p.exists():
            obj = json.loads(p.read_text())
            sanity[env] = {
                "control_event_rates_zero": all(
                    abs(float(obj["control_check"][k])) < 1e-12
                    for k in [
                        "control_push_event_rate",
                        "control_slip_active_rate",
                        "control_sensor_active_rate",
                        "control_obs_diff_norm_mean",
                        "control_obs_diff_norm_max",
                    ]
                ),
                "push_force_on_gt_off": obj["push_sanity"]["mean_push_force_when_event_1"]
                > obj["push_sanity"]["mean_push_force_when_event_0"],
                "slip_friction_active_lower": obj["slip_sanity"]["mean_friction_scale_when_active_1"]
                < obj["slip_sanity"]["mean_friction_scale_when_active_0"],
                "sensor_obs_diff_active_gt_inactive": obj["sensor_sanity"]["mean_obs_diff_norm_when_active_1"]
                > obj["sensor_sanity"]["mean_obs_diff_norm_when_active_0"],
            }
    validation["perturbation_sanity"] = sanity

    code_checks = {}
    files_to_check = {
        "cerebellum_bound": ROOT / "paper/experiments/sc_ncap/circuits/cerebellum.py",
        "imitation_target": ROOT / "paper/experiments/sc_ncap/scripts/train_cerebellum_imitation.py",
        "policy_composition": ROOT / "paper/experiments/sc_ncap/policies/cortex_residual_policy.py",
        "consolidation_target": ROOT / "paper/experiments/sc_ncap/scripts/collect_consolidation_dataset.py",
    }
    code_checks["cerebellum_bound"] = "delta_u_max * torch.tanh" in files_to_check["cerebellum_bound"].read_text()
    code_checks["imitation_target_delta"] = "target_t = u_teacher_t - u_ctx_t" in files_to_check["imitation_target"].read_text()
    code_checks["policy_action_composition"] = "u_final = torch.clamp(u_ctx + delta_gated" in files_to_check["policy_composition"].read_text()
    code_checks["consolidation_uses_u_final"] = 'u_final = extras.get("u_final")' in files_to_check["consolidation_target"].read_text()
    validation["source_code_checks"] = code_checks

    videos = []
    if P.video_index.exists():
        vdf = pd.read_csv(P.video_index)
        videos = [str(p) for p in vdf["curated_path"].head(12)]
    validation["representative_video_index_exists"] = P.video_index.exists()
    validation["representative_video_examples"] = videos

    validation["notes"] = [
        "This validation reads saved artifacts only; it does not re-run training.",
        "No invalidating issue was found in the checked equations, action-composition code, or perturbation sanity summaries.",
        "The morphology scaling result remains exploratory: n=4 environments is not enough for a strong evolutionary scaling claim.",
    ]
    (TABLE_DIR / "stats_validation.json").write_text(json.dumps(validation, indent=2))

    md = [
        "# Validation notes",
        "",
        "I checked the saved statistics and the source-code pathways used by the micropublication figures.",
        "",
        "## Result table checks",
        f"- Humanoid headline rows report N=20 seeds: `{validation['humanoid20_all_key_rows_n20']}`.",
        f"- Imitation fall AUC confidence intervals exclude zero: `{validation['humanoid20_imitation_fall_ci_excludes_zero']}`.",
        f"- Consolidated cortex fall AUC confidence intervals exclude zero: `{validation['humanoid20_consolidated_fall_ci_excludes_zero']}`.",
        "",
        "## Perturbation sanity checks",
        "The four environment summaries report zero event rates in no-perturb controls, positive applied push forces only during push windows, lower friction during slip windows, and larger observation differences during sensor-corruption windows.",
        "",
        "## Source-code checks",
        f"- Bounded cerebellar residual: `{code_checks['cerebellum_bound']}`.",
        f"- Imitation target is teacher minus cortex: `{code_checks['imitation_target_delta']}`.",
        f"- Final policy action uses cortex plus gated residual: `{code_checks['policy_action_composition']}`.",
        f"- Consolidation data target uses executed final action: `{code_checks['consolidation_uses_u_final']}`.",
        "",
        "## Caveats",
        "- The main Humanoid result is strong and uses N=20. Cross-environment results use smaller replication counts and are presented more cautiously.",
        "- The morphology/evolutionary discussion is a hypothesis-generating observation, not a formal phylogenetic or evolutionary test.",
    ]
    (PKG / "VALIDATION.md").write_text("\n".join(md) + "\n")
    return validation


def build_figures(data: Dict[str, object]) -> None:
    hs: pd.DataFrame = data["humanoid_summary"]
    ce: pd.DataFrame = data["cross_env_micro"]
    fail: pd.DataFrame = data["failure_fall"]
    tq: pd.DataFrame = data["teacher_quality"]
    morph: pd.DataFrame = data["morphology"]

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.titleweight": "bold",
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )

    colors = {
        "ctx": "#3949ab",
        "cb": "#009688",
        "teacher": "#f57c00",
        "bad": "#c62828",
        "muted": "#607d8b",
        "gray": "#eeeeee",
    }

    fig = plt.figure(figsize=(12.8, 8.8), constrained_layout=True)
    gs = fig.add_gridspec(2, 2, height_ratios=[1.04, 1.0], width_ratios=[1.12, 1.0])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[1, 0])
    ax3 = fig.add_subplot(gs[1, 1])

    ax0.set_axis_off()
    ax0.set_title("A  Teacher-guided corrective residual", loc="left", pad=8)
    boxes = [
        ("PPO teacher\ntrained with perturbations", 0.04, 0.66, 0.28, 0.18, colors["teacher"]),
        ("Cortex policy\nu_ctx", 0.04, 0.25, 0.25, 0.16, colors["ctx"]),
        ("Cerebellum residual\nDelta u = u_teacher - u_ctx", 0.42, 0.45, 0.34, 0.20, colors["cb"]),
        ("Final motor command\nclip(u_ctx + alpha Delta u)", 0.56, 0.12, 0.35, 0.18, "#455a64"),
    ]
    for text, x, y, w, h, c in boxes:
        rect = patches.FancyBboxPatch(
            (x, y),
            w,
            h,
            boxstyle="round,pad=0.015,rounding_size=0.03",
            linewidth=1.4,
            edgecolor=c,
            facecolor=c,
            alpha=0.14,
        )
        ax0.add_patch(rect)
        ax0.text(x + w / 2, y + h / 2, text, ha="center", va="center", color="#111111", fontsize=9)
    arrow_kw = dict(arrowstyle="->", lw=1.6, color="#333333")
    ax0.annotate("", xy=(0.42, 0.55), xytext=(0.32, 0.75), arrowprops=arrow_kw)
    ax0.annotate("", xy=(0.42, 0.53), xytext=(0.29, 0.33), arrowprops=arrow_kw)
    ax0.annotate("", xy=(0.63, 0.31), xytext=(0.60, 0.45), arrowprops=arrow_kw)
    ax0.annotate("", xy=(0.57, 0.20), xytext=(0.29, 0.32), arrowprops=arrow_kw)
    ax0.text(
        0.04,
        0.02,
        "The residual learns the teacher's fast correction, not a new reward function.",
        fontsize=9,
        color="#333333",
    )

    sweeps = ["push", "sensor", "slip"]
    comparisons = ["imitation_on_minus_off", "consolidated_minus_baseline"]
    labels = ["imitation ON - OFF", "consolidated - baseline"]
    xpos = np.arange(len(sweeps))
    width = 0.34
    for j, comp in enumerate(comparisons):
        means, lows, highs = [], [], []
        for sw in sweeps:
            r = _metric_row(hs, comp, "fall", sw)
            y, (lo, hi) = -float(r["mean"]), _ci_err_for_delta(r, sign=-1.0)
            means.append(y)
            lows.append(lo)
            highs.append(hi)
        ax1.bar(xpos + (j - 0.5) * width, means, width=width, label=labels[j], color=[colors["cb"], "#26a69a"][j])
        ax1.errorbar(xpos + (j - 0.5) * width, means, yerr=[lows, highs], fmt="none", ecolor="#222222", capsize=3, lw=1)
    ax1.axhline(0, color="#333333", lw=0.8)
    ax1.set_xticks(xpos)
    ax1.set_xticklabels(["push", "sensor", "slip"])
    ax1.set_ylabel("fall-AUC reduction\n(higher is better)")
    ax1.set_title("B  Humanoid reflex survival, N=20", loc="left")
    ax1.legend(frameon=False, fontsize=8, loc="upper left")
    ax1.set_ylim(0, 0.62)

    for j, comp in enumerate(comparisons):
        means, lows, highs = [], [], []
        for sw in sweeps:
            r = _metric_row(hs, comp, "return", sw)
            y, (lo, hi) = float(r["mean"]), _ci_err_for_delta(r, sign=1.0)
            means.append(y)
            lows.append(lo)
            highs.append(hi)
        ax2.bar(xpos + (j - 0.5) * width, means, width=width, label=labels[j], color=[colors["teacher"], "#ffb74d"][j])
        ax2.errorbar(xpos + (j - 0.5) * width, means, yerr=[lows, highs], fmt="none", ecolor="#222222", capsize=3, lw=1)
    ax2.axhline(0, color="#333333", lw=0.8)
    ax2.set_xticks(xpos)
    ax2.set_xticklabels(["push", "sensor", "slip"])
    ax2.set_ylabel("return-AUC gain\n(higher is better)")
    ax2.set_title("C  Same checkpoints also gain return", loc="left")
    ax2.legend(frameon=False, fontsize=8, loc="upper left")

    morph_plot = morph.copy()
    morph_plot["fall_reduction"] = -morph_plot["mean_fall_auc_delta_imitation_on_off"]
    sizes = 50 + 45 * morph_plot["max_simultaneous_contacts"].astype(float)
    ax3.scatter(
        morph_plot["n_actuated_joints"],
        morph_plot["fall_reduction"],
        s=sizes,
        color="#5e35b1",
        alpha=0.82,
        edgecolor="white",
        linewidth=0.8,
    )
    for _, row in morph_plot.iterrows():
        label = str(row["env_id"]).replace("-v4", "")
        ax3.text(row["n_actuated_joints"] + 0.25, row["fall_reduction"] + 0.012, label, fontsize=8)
    ax3.set_xlabel("actuated joints")
    ax3.set_ylabel("mean fall-AUC reduction")
    ax3.set_title("D  Exploratory morphology analysis", loc="left")
    ax3.text(
        0.03,
        0.90,
        "Contact-rich bodies often benefit more,\nbut n=4 environments is only suggestive.",
        transform=ax3.transAxes,
        fontsize=8,
        color="#333333",
        bbox=dict(boxstyle="round,pad=0.28", fc="white", ec="#cccccc"),
    )
    _savefig(fig, "RNNematode-Figures")

    # Supplementary figure for checks and negative results.
    fig2, axes = plt.subplots(2, 2, figsize=(12.8, 8.5), constrained_layout=True)
    ax = axes[0, 0]
    fail_comp = fail[
        fail["method_key"].isin(
            [
                "mlp_ppo",
                "spinal_static",
                "sc_ncap",
                "cortex_residual_rl",
                "curriculum_residual",
                "bg_gate_residual",
                "stability_aux_residual",
                "imitation",
            ]
        )
        & (fail["sweep_type"] == "push")
    ].copy()
    order = [
        "mlp_ppo",
        "spinal_static",
        "sc_ncap",
        "cortex_residual_rl",
        "curriculum_residual",
        "bg_gate_residual",
        "stability_aux_residual",
        "imitation",
    ]
    fail_comp["method_key"] = pd.Categorical(fail_comp["method_key"], categories=order, ordered=True)
    fail_comp = fail_comp.sort_values("method_key")
    yvals = -fail_comp["delta_vs_baseline"].values
    ax.barh(range(len(fail_comp)), yvals, color=["#b0bec5"] * (len(fail_comp) - 1) + [colors["cb"]])
    ax.axvline(0, color="#333333", lw=0.8)
    ax.set_yticks(range(len(fail_comp)))
    ax.set_yticklabels([str(x).replace("Cortex+", "Ctx+") for x in fail_comp["method_label"]], fontsize=7)
    ax.set_xlabel("fall-AUC reduction vs MLP\n(positive = improvement)")
    ax.set_title("S1  RL-only corrections did not reliably help", loc="left")

    ax = axes[0, 1]
    tq_plot = tq[tq["teacher_variant"].isin(["T_full", "T_weak"])].copy()
    x = np.arange(3)
    for j, variant in enumerate(["T_full", "T_weak"]):
        sub = tq_plot[tq_plot["teacher_variant"] == variant].set_index("sweep_type").loc[sweeps]
        vals = -sub["delta_auc_fall_mean"].values
        err_low = vals - (-sub["delta_auc_fall_ci_high"].values)
        err_high = (-sub["delta_auc_fall_ci_low"].values) - vals
        ax.bar(x + (j - 0.5) * width, vals, width=width, label=variant, color=[colors["cb"], colors["bad"]][j])
        ax.errorbar(x + (j - 0.5) * width, vals, yerr=[err_low, err_high], fmt="none", ecolor="#222222", capsize=3)
    ax.axhline(0, color="#333333", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(["push", "sensor", "slip"])
    ax.set_ylabel("student fall-AUC reduction")
    ax.set_title("S2  Teacher quality changes the sign", loc="left")
    ax.legend(frameon=False, fontsize=8)

    ax = axes[1, 0]
    sanity_rows = []
    for env in ["humanoid", "walker2d", "ant", "hopper"]:
        p = RESULTS / f"{env}_perturbation_sanity_summary.json"
        if p.exists():
            obj = json.loads(p.read_text())
            sanity_rows.append(
                {
                    "env": env,
                    "push": obj["push_sanity"]["mean_push_force_when_event_1"]
                    - obj["push_sanity"]["mean_push_force_when_event_0"],
                    "sensor": obj["sensor_sanity"]["mean_obs_diff_norm_when_active_1"]
                    - obj["sensor_sanity"]["mean_obs_diff_norm_when_active_0"],
                    "slip": obj["slip_sanity"]["mean_friction_scale_when_active_0"]
                    - obj["slip_sanity"]["mean_friction_scale_when_active_1"],
                }
            )
    sanity_df = pd.DataFrame(sanity_rows)
    sanity_df.to_csv(TABLE_DIR / "perturbation_sanity_compact.csv", index=False)
    sanity_tex = sanity_df.copy()
    for col in ["push", "slip", "sensor"]:
        sanity_tex[col] = sanity_tex[col].map(lambda x: f"{x:.3f}")
    (PKG / "tables" / "perturbation_sanity_compact.tex").write_text(
        sanity_tex.to_latex(index=False, escape=True)
    )
    xx = np.arange(len(sanity_df))
    for j, k in enumerate(["push", "slip", "sensor"]):
        vals = sanity_df[k].values
        vals_norm = vals / (np.max(vals) if np.max(vals) > 0 else 1.0)
        ax.bar(xx + (j - 1) * 0.23, vals_norm, width=0.22, label=k)
    ax.set_xticks(xx)
    ax.set_xticklabels(sanity_df["env"].str.replace("walker2d", "walker"), rotation=0)
    ax.set_ylim(0, 1.2)
    ax.set_ylabel("normalized on/off effect")
    ax.set_title("S3  Perturbations are physically applied", loc="left")
    ax.legend(frameon=False, fontsize=8)

    ax = axes[1, 1]
    ce_plot = ce[ce["source"] == "imitation_on_minus_off"].copy()
    piv = ce_plot.pivot(index="env", columns="metric", values="mean")
    ax.scatter(piv["return"], -piv["fall"], s=95, color="#00897b", alpha=0.85, edgecolor="white")
    for env, row in piv.iterrows():
        ax.text(row["return"] + 3, -row["fall"] + 0.015, env.replace("-v4", ""), fontsize=8)
    ax.axhline(0, color="#333333", lw=0.8)
    ax.axvline(0, color="#333333", lw=0.8)
    ax.set_xlabel("return-AUC gain")
    ax.set_ylabel("fall-AUC reduction")
    ax.set_title("S4  Hopper exposes a performance tradeoff", loc="left")
    _savefig(fig2, "RNNematode-Supplementary-Figures")


def build_contributions() -> None:
    rows = [
        {
            "Name": "Andres de Vicente",
            "Role": "Equal-contributing author",
            "Contributions": "Project conception, BrainCAD/SC-NCAP implementation, teacher-guided residual pipeline, experiments, figures, and writing.",
        },
        {
            "Name": "Renee Vieira",
            "Role": "Equal-contributing author",
            "Contributions": "Project conception, neuroscience framing, result interpretation, analysis review, and manuscript editing.",
        },
        {
            "Name": "Charlie Hou",
            "Role": "Equal-contributing author",
            "Contributions": "Project conception, modeling discussions, analysis review, result interpretation, and manuscript editing.",
        },
        {
            "Name": "Raymond Chua",
            "Role": "Senior mentor",
            "Contributions": "Scientific mentorship, project guidance, feedback on motor-control framing, and review of conclusions.",
        },
    ]
    df = pd.DataFrame(rows)
    df.to_csv(PKG / "RNNematode-Contributions.csv", index=False)
    wb = Workbook()
    ws = wb.active
    ws.title = "Contributions"
    ws.append(list(df.columns))
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="455A64")
    for row in rows:
        ws.append([row["Name"], row["Role"], row["Contributions"]])
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 92
    wb.save(PKG / "RNNematode-Contributions.xlsx")

    credit_roles = [
        "Conceptualization",
        "Data curation",
        "Formal analysis",
        "Funding acquisition",
        "Investigation",
        "Methodology",
        "Project administration",
        "Resources",
        "Software",
        "Supervision",
        "Validation",
        "Visualization",
        "Writing - original draft",
        "Writing - review & editing",
        "Notes",
    ]
    credit_rows = [
        {
            "Contributor": "Andres de Vicente",
            "Conceptualization": "Lead",
            "Data curation": "Lead",
            "Formal analysis": "Lead",
            "Funding acquisition": "",
            "Investigation": "Lead",
            "Methodology": "Lead",
            "Project administration": "Lead",
            "Resources": "Lead",
            "Software": "Lead",
            "Supervision": "",
            "Validation": "Lead",
            "Visualization": "Lead",
            "Writing - original draft": "Lead",
            "Writing - review & editing": "Lead",
            "Notes": "Equal-contributing scholar; ORCID: https://orcid.org/0000-0003-4995-4473.",
        },
        {
            "Contributor": "Renee Vieira",
            "Conceptualization": "Lead",
            "Data curation": "",
            "Formal analysis": "Support",
            "Funding acquisition": "",
            "Investigation": "Lead",
            "Methodology": "Support",
            "Project administration": "Support",
            "Resources": "",
            "Software": "",
            "Supervision": "",
            "Validation": "Support",
            "Visualization": "Support",
            "Writing - original draft": "Lead",
            "Writing - review & editing": "Lead",
            "Notes": "Equal-contributing scholar; ORCID to be added in submission form.",
        },
        {
            "Contributor": "Charlie Hou",
            "Conceptualization": "Lead",
            "Data curation": "",
            "Formal analysis": "Support",
            "Funding acquisition": "",
            "Investigation": "Lead",
            "Methodology": "Support",
            "Project administration": "Support",
            "Resources": "",
            "Software": "",
            "Supervision": "",
            "Validation": "Support",
            "Visualization": "Support",
            "Writing - original draft": "Lead",
            "Writing - review & editing": "Lead",
            "Notes": "Equal-contributing scholar; ORCID to be added in submission form.",
        },
    ]
    credit_df = pd.DataFrame(credit_rows, columns=["Contributor"] + credit_roles)
    credit_df.to_csv(PKG / "ISP_RNNematode_CRediT_contributors.csv", index=False)


def build_notebooks() -> None:
    nb1 = nbf.v4.new_notebook()
    nb1["cells"] = [
        nbf.v4.new_markdown_cell(
            "# Model equations: cortex, teacher, and cerebellum\n\n"
            "This short notebook is meant as a readable entry point.  It does not train a policy.  "
            "It shows the action decomposition used in the project: a cortex policy proposes a movement, "
            "a teacher policy supplies a corrective target during perturbation windows, and a cerebellum-like "
            "module learns the residual between them."
        ),
        nbf.v4.new_markdown_cell(
            "The main supervised target is\n\n"
            "$$\\Delta u_t^* = u_t^{teacher} - u_t^{ctx},$$\n\n"
            "and the executed residual policy is\n\n"
            "$$u_t = \\mathrm{clip}(u_t^{ctx} + \\alpha_t\\Delta u_t, u_{min}, u_{max}).$$\n\n"
            "The gate $\\alpha_t$ is optional.  In the strongest result the important part was not the gate, "
            "but the teacher-provided residual target."
        ),
        nbf.v4.new_code_cell(
            "import numpy as np\n"
            "rng = np.random.default_rng(7)\n"
            "action_dim = 6\n"
            "u_ctx = rng.normal(0, 0.25, size=action_dim)\n"
            "u_teacher = u_ctx + rng.normal(0, 0.10, size=action_dim)\n"
            "delta_star = u_teacher - u_ctx\n"
            "alpha = 0.8\n"
            "u_final = np.clip(u_ctx + alpha * delta_star, -1.0, 1.0)\n"
            "print('cortex action:', np.round(u_ctx, 3))\n"
            "print('teacher action:', np.round(u_teacher, 3))\n"
            "print('residual target:', np.round(delta_star, 3))\n"
            "print('executed action:', np.round(u_final, 3))"
        ),
        nbf.v4.new_markdown_cell(
            "In biological language, this is closer to an error-correction pathway than to a replacement motor cortex.  "
            "The residual is only asked to learn the difference between a nominal motor command and a stronger perturbation-trained command."
        ),
    ]
    nbf.write(nb1, CODE_DIR / "01_model_equations_and_action_decomposition.ipynb")

    nb2 = nbf.v4.new_notebook()
    nb2["cells"] = [
        nbf.v4.new_markdown_cell(
            "# Reproducing the main Humanoid numbers\n\n"
            "This notebook reads the saved N=20 Humanoid summary table and replots the two headline quantities: "
            "fall-AUC reduction and return-AUC gain.  Lower fall AUC is better, so the notebook flips the sign "
            "and plots a positive 'fall reduction'."
        ),
        nbf.v4.new_code_cell(
            "from pathlib import Path\n"
            "import pandas as pd\n"
            "import matplotlib.pyplot as plt\n"
            "\n"
            "def find_submission_root(start=None):\n"
            "    start = Path.cwd() if start is None else Path(start).resolve()\n"
            "    for p in [start, *start.parents]:\n"
            "        if (p / 'derived_tables').exists() and (p / 'myst_submission').exists():\n"
            "            return p\n"
            "        if (p / 'myst.yml').exists() and (p.parent / 'derived_tables').exists():\n"
            "            return p.parent\n"
            "        if (p / 'index.md').exists() and (p.parent / 'derived_tables').exists():\n"
            "            return p.parent\n"
            "    return start\n"
            "\n"
            "ROOT = find_submission_root()\n"
            "summary_path = ROOT / 'derived_tables' / 'humanoid20_key_results.csv'\n"
            "if not summary_path.exists():\n"
            "    raise FileNotFoundError(\n"
            "        f'Missing saved results table: {summary_path}. ' +\n"
            "        'Place humanoid20_key_results.csv in derived_tables/ before running this notebook.'\n"
            "    )\n"
            "df = pd.read_csv(summary_path)\n"
            "df.head()"
        ),
        nbf.v4.new_code_cell(
            "plot_df = df[(df.comparison == 'imitation_on_minus_off') & (df.metric == 'fall')].copy()\n"
            "plot_df['fall_reduction'] = -plot_df['mean']\n"
            "ax = plot_df.plot.bar(x='sweep_type', y='fall_reduction', legend=False, color='#009688')\n"
            "ax.set_ylabel('fall-AUC reduction')\n"
            "ax.set_xlabel('perturbation')\n"
            "ax.set_title('Teacher-guided residual improves survival in Humanoid')\n"
            "plt.tight_layout()"
        ),
        nbf.v4.new_code_cell(
            "for _, row in plot_df.iterrows():\n"
            "    print(f\"{row.sweep_type}: fall delta={row['mean']:.3f}, 95% CI=[{row.ci_low:.3f}, {row.ci_high:.3f}], n={int(row.n_seeds)}\")"
        ),
    ]
    nbf.write(nb2, CODE_DIR / "02_reproduce_main_humanoid_results.ipynb")

    nb3 = nbf.v4.new_notebook()
    nb3["cells"] = [
        nbf.v4.new_markdown_cell(
            "# Video index\n\n"
            "The videos are not needed to compute the statistics, but they are useful for seeing what the benchmark is doing.  "
            "The packaged CSV is a validation artifact that lists representative nominal, moderate, and severe episodes for several methods and bodies.  "
            "The actual MP4 files are optional; if they are included, their paths are listed in the index."
        ),
        nbf.v4.new_code_cell(
            "from pathlib import Path\n"
            "import pandas as pd\n"
            "\n"
            "def find_submission_root(start=None):\n"
            "    start = Path.cwd() if start is None else Path(start).resolve()\n"
            "    for p in [start, *start.parents]:\n"
            "        if (p / 'video_index').exists() and (p / 'myst_submission').exists():\n"
            "            return p\n"
            "        if (p / 'myst.yml').exists() and (p.parent / 'video_index').exists():\n"
            "            return p.parent\n"
            "        if (p / 'index.md').exists() and (p.parent / 'video_index').exists():\n"
            "            return p.parent\n"
            "    return start\n"
            "\n"
            "ROOT = find_submission_root()\n"
            "video_index = ROOT / 'video_index' / 'representative_video_index.csv'\n"
            "if not video_index.exists():\n"
            "    raise FileNotFoundError(\n"
            "        f'Missing video validation index: {video_index}. ' +\n"
            "        'Place representative_video_index.csv in video_index/ before running this notebook.'\n"
            "    )\n"
            "df = pd.read_csv(video_index)\n"
            "print('video rows indexed:', len(df))\n"
            "print('MP4 files are optional; this CSV records the validation index used for representative videos.')\n"
            "df[['env','method','tier','kind','severity','curated_path']].head(12)"
        ),
        nbf.v4.new_code_cell(
            "for env in sorted(df.env.unique()):\n"
            "    severe = df[(df.env == env) & (df.tier == 'severe')]\n"
            "    print('\\n' + env)\n"
            "    for _, row in severe.head(4).iterrows():\n"
            "        print(f\"  {row.method}: {row.curated_path}\")"
        ),
    ]
    nbf.write(nb3, CODE_DIR / "03_reflexbench_video_index.ipynb")


def build_myst_submission() -> None:
    myst_dir = PKG / "myst_submission"
    fig_dir = myst_dir / "figures"
    myst_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(FIG_DIR / "RNNematode-Figures.svg", fig_dir / "RNNematode-Figures.svg")
    shutil.copy2(PKG / "references.bib", myst_dir / "references.bib")

    myst_yml = """version: 1
project:
  title: "Teacher-guided corrective residuals support reflex-like recovery in simulated locomotion"
  description: "A Neuromatch Impact Scholars micropublication from Team RNNematode."
  keywords:
    - motor control
    - cerebellum
    - reinforcement learning
    - BrainCAD
  authors:
    - name: "Andres de Vicente"
      orcid: "https://orcid.org/0000-0003-4995-4473"
      affiliations:
        - "Neuromatch Impact Scholars Program, Team RNNematode"
    - name: "Renee Vieira"
      affiliations:
        - "Neuromatch Impact Scholars Program, Team RNNematode"
    - name: "Charlie Hou"
      affiliations:
        - "Neuromatch Impact Scholars Program, Team RNNematode"
  bibliography:
    - references.bib
  license: "CC-BY-4.0"
site:
  template: book-theme
"""
    (myst_dir / "myst.yml").write_text(myst_yml)

    index = """---
title: Teacher-guided corrective residuals support reflex-like recovery in simulated locomotion
authors:
  - name: Andres de Vicente
    orcid: https://orcid.org/0000-0003-4995-4473
    affiliations: [Neuromatch Impact Scholars Program, Team RNNematode]
  - name: Renee Vieira
    affiliations: [Neuromatch Impact Scholars Program, Team RNNematode]
  - name: Charlie Hou
    affiliations: [Neuromatch Impact Scholars Program, Team RNNematode]
keywords:
  - motor control
  - cerebellum
  - reinforcement learning
  - BrainCAD
license: CC-BY-4.0
---

## Research type

**Claim.** In BrainCAD/ReflexBench locomotion experiments, cerebellar-inspired corrective modules improved reflex-like recovery only when trained with a structured teacher signal.

## Abstract

Animals do not recover from every stumble by relearning a motor policy. Recovery is more naturally described as layered control: an ongoing motor command is combined with faster corrective pathways shaped by error and practice. We tested this idea in BrainCAD, a biologically inspired neural-control toolkit built around MuJoCo locomotion experiments. Several reinforcement-learning-only corrective circuits, including spinal gain gating and residual modules, did not learn reliable fast recovery under PPO. A cerebellar-inspired residual became effective only when trained with a direct teacher signal. This is close to residual imitation and policy distillation; the contribution is not a new distillation algorithm, but a controlled demonstration that this learning signal was necessary in our biologically inspired locomotor-control architecture. In Humanoid-v4, same-checkpoint residual ON/OFF evaluation across 20 seeds reduced fall AUC and increased return AUC. The correction could also be distilled into a cortex-only policy, preserving most of the fall reduction.

## Description

Reflexes are often described as simple loops, but real movement is not simple. A body with many joints and contacts has many ways to fail: a foot can slip, sensory input can become unreliable, or a shove can arrive while the controller is already committed to a step. Nervous systems solve this with layered circuits. Spinal circuits provide fast sensorimotor pathways, cortex supports flexible voluntary control, and the cerebellum is strongly associated with internal models and error-based motor adaptation {cite:p}`wolpert1998internalmodels,ito2008control,seidler2013errorbased`.

Motivated by this organization, we implemented several corrective circuits in BrainCAD {cite:p}`braincad2026software` and tested them in ReflexBench, a perturbation suite for MuJoCo locomotion. The first lesson was negative: PPO alone {cite:p}`schulman2017ppo` often failed to discover a small, fast corrective action, even when the architecture was biologically plausible. The successful variant used a teacher. A robust policy was first trained under perturbations, and a cerebellar residual was then trained to imitate the teacher's correction relative to a nominal cortex. We therefore frame the result as a learning-signal result, not as evidence for a new principle of cerebellar biology.

The model has three pieces. A cortex policy proposes a base action,

$$u_t^{ctx} = \\pi_\\theta(o_t),$$

where $o_t$ is the observation. A teacher policy, trained separately with perturbations, produces $u_t^{teacher}$. During imitation, the cerebellar residual is trained toward

$$\\Delta u_t^* = u_t^{teacher} - u_t^{ctx}.$$

At evaluation time, the residual controller executes

$$u_t = \\mathrm{clip}(u_t^{ctx} + \\alpha_t \\Delta u_t, u_{min}, u_{max}),$$

where $\\alpha_t \\in [0,1]$ is an optional engagement gate. A later consolidation step removes the residual machinery by training a new cortex to imitate the final action directly.

```{figure} figures/RNNematode-Figures.svg
:name: fig-main
:width: 100%

Teacher-guided residual control and main results. A, a perturbation-trained teacher supplies a corrective target for a cerebellar residual. B, in Humanoid-v4, residual ON vs OFF evaluation with the same checkpoint reduces fall AUC across pushes, sensor corruption, and slips (N=20). C, the same comparison improves return AUC. D, exploratory morphology analysis across bodies.
```

RL-only correction was not enough. We first tested spinal gain gating, residual correction trained only by PPO, curriculum perturbations, basal-ganglia-like engagement gates, and stability auxiliary terms. These variants were useful diagnostics, but none gave a reliable causal reduction in fall AUC. Thus, the circuit diagram alone was not the main explanation. The key variable was whether the module received enough information to learn a useful correction at the right time.

Teacher-guided residuals improved survival. The residual was tested causally: the same checkpoint and the same perturbation schedule were evaluated with the residual enabled or disabled. In the N=20 Humanoid campaign, fall AUC decreased for push (-0.313, 95% CI [-0.491, -0.147]), sensor (-0.447, 95% CI [-0.553, -0.338]), and slip (-0.325, 95% CI [-0.511, -0.155]) perturbations. Return AUC increased for push (58.8, 95% CI [27.6, 88.4]), sensor (103.6, 95% CI [82.7, 123.5]), and slip (61.4, 95% CI [27.4, 91.6]). Fall AUC was computed as the area under the fall-probability curve across the predefined perturbation-severity grid; return AUC was computed analogously from mean return. Curves were computed per seed before paired ON-OFF deltas were summarized with bootstrap confidence intervals.

Teacher quality mattered. A strong teacher produced stabilizing residuals. A deliberately weak teacher produced residuals that could become harmful. This argues against a simple capacity explanation: the student learned a direction of correction from the teacher, and a bad teacher could teach the wrong direction.

Corrections could be consolidated. We trained a cortex-only policy to imitate the final action of the residual controller. This consolidated policy no longer used an online cerebellar residual, but it retained most of the fall reduction in Humanoid and generalized under a long-push schedule. This suggests that the residual pathway can act as a training scaffold: useful during learning, but not always necessary at inference.

Exploratory morphology analysis should be interpreted cautiously. Ant and Humanoid showed strong fall reductions, Walker2d replicated, and Hopper exposed a stability-performance tradeoff. This supports a modest morphology-dependent control hypothesis: layered corrections may become more useful as the body creates more recovery states for the controller to handle, but four simulated bodies cannot establish an evolutionary scaling law.

## Acknowledgments

This work was developed as part of the Neuromatch Impact Scholars Program by Team RNNematode. We thank Raymond Chua for senior mentorship, scientific guidance, and feedback on motor-control framing. We also acknowledge the BrainCAD/NCAP software infrastructure used for circuit templates, MuJoCo wrappers, evaluation, and video export.

## Code and data availability

The submitted code package includes notebooks that reproduce the main figure from saved result artifacts, validation tables, and instructions for accessing the saved BrainCAD/ReflexBench results. The public repository is available at https://github.com/andrestrocyte/rnnematode-micropublication.

## References

```{bibliography}
```
"""
    (myst_dir / "index.md").write_text(index)
    main_for_count = index.split("## Acknowledgments")[0]
    main_for_count = re.sub(r"---.*?---", "", main_for_count, count=1, flags=re.S)
    main_for_count = re.sub(r"```.*?```", "", main_for_count, flags=re.S)
    main_for_count = re.sub(r"\$\$.*?\$\$", "", main_for_count, flags=re.S)
    word_count = len(re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)?", main_for_count))
    if word_count > 1500:
        raise RuntimeError(f"MyST main text is {word_count} words, above the 1500-word limit")

    (myst_dir / "README_SUBMISSION.md").write_text(
        f"""# MyST micropublication submission

This folder contains the Impact Scholars micropublication source.

- Research type: Claim
- Title length: 88 characters
- Keywords: motor control, cerebellum, reinforcement learning, BrainCAD
- Main text word count: {word_count} words, excluding references and acknowledgments
- License: CC-BY-4.0

Andres de Vicente ORCID is included. Before final form submission, add ORCID IDs for Renee Vieira and Charlie Hou in the submission form or MyST frontmatter if required.

## Reproducing the figure and validation summaries

Run the notebooks in order:

1. `Codes/01_model_equations_and_action_decomposition.ipynb`
2. `Codes/02_reproduce_main_humanoid_results.ipynb`
3. `Codes/03_reflexbench_video_index.ipynb`

The notebooks use relative paths from the submission root and do not retrain policies. They reproduce the submitted figure summaries and summarize validation artifacts from saved BrainCAD/ReflexBench result tables.

Expected packaged artifacts:

- `derived_tables/humanoid20_key_results.csv`
- `video_index/representative_video_index.csv`
"""
    )


def build_submission_checklist() -> None:
    checklist = """# Impact Scholars submission checklist

This file maps the package to the current Neuromatch Impact Scholars micropublication requirements.

| Requirement | Status | Package location / note |
|---|---|---|
| Research type | Claim | The claim is stated in `myst_submission/index.md`. |
| One focused result/method/claim | Yes | The package is centered on one claim: teacher-guided corrective residuals support reflex-like recovery in BrainCAD/ReflexBench when PPO-only corrective circuits do not. |
| Title <= 100 characters | Yes | 88 characters: "Teacher-guided corrective residuals support reflex-like recovery in simulated locomotion". |
| 3-4 keywords | Yes | motor control; cerebellum; reinforcement learning; BrainCAD. |
| MyST Markdown main text | Yes | `myst_submission/index.md`. |
| Main text <= 1500 words | Yes | Checked by the build; acknowledgments and references are excluded. |
| Acknowledgment section | Yes | Raymond Chua is acknowledged for senior mentorship in the MyST source. |
| CRediT author contributions | Yes | `ISP_RNNematode_CRediT_contributors.csv` contains the three scholar authors; Raymond Chua is acknowledged separately as senior mentor. |
| ORCID transparency | Partial | Andres de Vicente ORCID is included: https://orcid.org/0000-0003-4995-4473. Add Renee and Charlie ORCID IDs in the submission form if available. |
| Reproducible code package | Yes | `RNNematode_micropublication_code.zip`. |
| Code instructions | Yes | `CODE_README.txt`. |
| Open formats | Yes | `.md`, `.tex`, `.svg`, `.csv`, `.ipynb`, `.py`, `.zip`. |
| Supplementary material | Yes | Technical report, supplementary figure, validation notes, and notebooks are included in the package. |
"""
    (PKG / "SUBMISSION_CHECKLIST.md").write_text(checklist)


def build_code_readme_and_zip() -> None:
    code_readme = """RNNematode micropublication code package

Purpose
-------
This code package reproduces the figures and tables used in the micropublication from saved BrainCAD/ReflexBench result artifacts. It does not rerun training.

How to run
----------
1. Open a terminal.
2. Run:

   cd rnnematode-micropublication
   ./commands_session.sh

Included notebooks
------------------
- Codes/01_model_equations_and_action_decomposition.ipynb
  Minimal action-composition example for cortex, teacher, and residual.
- Codes/02_reproduce_main_humanoid_results.ipynb
  Replots headline Humanoid fall/return AUC results from saved CSVs.
- Codes/03_reflexbench_video_index.ipynb
  Lists representative saved videos.

Data access
-----------
The notebooks read saved result artifacts packaged with the submission:
- derived_tables/humanoid20_key_results.csv
- video_index/representative_video_index.csv
- Figures/ and tables/ for the submitted plots and report

No proprietary software is required. The package uses Python, pandas, numpy, matplotlib, nbformat, openpyxl, and LaTeX for local rebuilding.
"""
    (PKG / "CODE_README.txt").write_text(code_readme)

    zip_path = PKG / "RNNematode_micropublication_code.zip"
    if zip_path.exists():
        zip_path.unlink()
    include_dirs = ["Codes", "scripts", "derived_tables", "tables", "Figures", "myst_submission", "video_index"]
    include_files = [
        "README.md",
        "CODE_README.txt",
        "commands_session.sh",
        "build.sh",
        "references.bib",
        "VALIDATION.md",
        "SUBMISSION_CHECKLIST.md",
        "RNNematode-Contributions.csv",
        "ISP_RNNematode_CRediT_contributors.csv",
    ]
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for d in include_dirs:
            base = PKG / d
            if not base.exists():
                continue
            for path in base.rglob("*"):
                if path.is_file() and "__pycache__" not in path.parts:
                    zf.write(path, path.relative_to(PKG))
        for f in include_files:
            path = PKG / f
            if path.exists():
                zf.write(path, path.relative_to(PKG))


def _humanoid_numbers(hs: pd.DataFrame) -> Dict[str, float]:
    out: Dict[str, float] = {}
    im_fall = hs[(hs["comparison"] == "imitation_on_minus_off") & (hs["metric"] == "fall")]
    con_fall = hs[(hs["comparison"] == "consolidated_minus_baseline") & (hs["metric"] == "fall")]
    im_ret = hs[(hs["comparison"] == "imitation_on_minus_off") & (hs["metric"] == "return")]
    con_ret = hs[(hs["comparison"] == "consolidated_minus_baseline") & (hs["metric"] == "return")]
    out["mean_im_fall_reduction"] = -float(im_fall["mean"].mean())
    out["mean_con_fall_reduction"] = -float(con_fall["mean"].mean())
    out["mean_im_return_gain"] = float(im_ret["mean"].mean())
    out["mean_con_return_gain"] = float(con_ret["mean"].mean())
    out["push_im_fall"] = float(_metric_row(hs, "imitation_on_minus_off", "fall", "push")["mean"])
    out["sensor_im_fall"] = float(_metric_row(hs, "imitation_on_minus_off", "fall", "sensor")["mean"])
    out["slip_im_fall"] = float(_metric_row(hs, "imitation_on_minus_off", "fall", "slip")["mean"])
    for sweep in ["push", "sensor", "slip"]:
        for metric in ["fall", "return"]:
            r = _metric_row(hs, "imitation_on_minus_off", metric, sweep)
            out[f"{sweep}_im_{metric}_mean"] = float(r["mean"])
            out[f"{sweep}_im_{metric}_low"] = float(r["ci_low"])
            out[f"{sweep}_im_{metric}_high"] = float(r["ci_high"])
    return out


def _delta_ci_text(nums: Dict[str, float], sweep: str, metric: str, digits: int = 3) -> str:
    mean = nums[f"{sweep}_im_{metric}_mean"]
    low = nums[f"{sweep}_im_{metric}_low"]
    high = nums[f"{sweep}_im_{metric}_high"]
    return f"{mean:.{digits}f}, 95\\% CI [{low:.{digits}f}, {high:.{digits}f}]"


def build_tex(data: Dict[str, object]) -> None:
    hs: pd.DataFrame = data["humanoid_summary"]
    nums = _humanoid_numbers(hs)
    fall_ci_push = _delta_ci_text(nums, "push", "fall")
    fall_ci_sensor = _delta_ci_text(nums, "sensor", "fall")
    fall_ci_slip = _delta_ci_text(nums, "slip", "fall")
    ret_ci_push = _delta_ci_text(nums, "push", "return", digits=1)
    ret_ci_sensor = _delta_ci_text(nums, "sensor", "return", digits=1)
    ret_ci_slip = _delta_ci_text(nums, "slip", "return", digits=1)
    title = "Teacher-guided corrective residuals support reflex-like recovery in simulated locomotion"

    micro = rf"""\documentclass[11pt]{{article}}
\usepackage[margin=0.78in]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{amsmath,amssymb}}
\usepackage{{booktabs}}
\usepackage{{url}}
\usepackage[numbers,sort&compress]{{natbib}}
\usepackage{{authblk}}
\usepackage{{hyperref}}
\hypersetup{{colorlinks=true,linkcolor=black,citecolor=black,urlcolor=blue}}
\setlength{{\parskip}}{{0.55em}}
\setlength{{\parindent}}{{0pt}}

\title{{{title}}}
\author[1,*]{{Andr\'es de Vicente}}
\author[1,*]{{Renee Vieira}}
\author[1,*]{{Charlie Hou}}
\affil[1]{{Neuromatch Impact Scholars Program, Team RNNematode}}
\affil[*]{{Equal contribution}}
\date{{2026}}

\begin{{document}}
\maketitle

\textbf{{Keywords:}} motor control; cerebellum; residual policy; reinforcement learning; locomotion; reflexes; BrainCAD

\begin{{abstract}}
Animals do not recover from every stumble by relearning a motor policy.  Recovery is more naturally described as layered control: an ongoing motor command is combined with faster corrective pathways shaped by error and practice.  We tested this idea in BrainCAD, a biologically inspired neural-control toolkit built around MuJoCo locomotion experiments.  Several reinforcement-learning-only corrective circuits, including spinal gain gating and residual modules, did not learn reliable fast recovery under PPO.  A cerebellar-inspired residual became effective only when trained with a direct teacher signal.  This is close to residual imitation and policy distillation; the contribution is not a new distillation algorithm, but a controlled demonstration that this learning signal was necessary in our biologically inspired locomotor-control architecture.  In Humanoid-v4, the same trained checkpoint was evaluated with the residual switched on and off under identical perturbation schedules.  Across 20 seeds, the residual reduced fall AUC by {nums['mean_im_fall_reduction']:.3f} on average and increased return AUC by {nums['mean_im_return_gain']:.1f}.  The correction could also be distilled into a cortex-only policy, preserving most of the fall reduction.  Cross-body experiments showed strong effects in Humanoid, Walker2d, and Ant, with Hopper as a boundary case where stability gains were less clean and return often decreased.  These results suggest that biologically inspired corrective modules require an appropriately structured learning signal, not just an anatomically motivated architecture.
\end{{abstract}}

\section*{{Introduction}}
Reflexes are often described as simple loops, but real movement is not simple.  A body with many joints and contacts has many ways to fail: a foot can slip, sensory input can become unreliable, or a shove can arrive while the controller is already committed to a step.  Nervous systems solve this with layered circuits.  Spinal circuits provide fast sensorimotor pathways, cortex supports flexible voluntary control, and the cerebellum is strongly associated with internal models and error-based motor adaptation \citep{{wolpert1998internalmodels,ito2008control,seidler2013errorbased}}.

Motivated by this organization, we implemented several corrective circuits in BrainCAD \citep{{braincad2026software}} and tested them in ReflexBench, a perturbation suite for MuJoCo locomotion.  The first lesson was negative: PPO alone \citep{{schulman2017ppo}} often failed to discover a small, fast corrective action, even when the architecture was biologically plausible.  The successful variant used a teacher.  A robust policy was first trained under perturbations, and a cerebellar residual was then trained to imitate the teacher's correction relative to a nominal cortex.  We therefore frame the result as a learning-signal result, not as evidence for a new principle of cerebellar biology.

\section*{{Model}}
The model has three pieces.  A cortex policy proposes a base action,
\[
u_t^{{ctx}} = \pi_\theta(o_t),
\]
where $o_t$ is the observation.  A teacher policy, trained separately with perturbations, produces $u_t^{{teacher}}$.  During imitation, the cerebellar residual is trained toward
\[
\Delta u_t^* = u_t^{{teacher}} - u_t^{{ctx}}.
\]
At evaluation time, the residual controller executes
\[
u_t = \mathrm{{clip}}\left(u_t^{{ctx}} + \alpha_t \Delta u_t, u_{{min}}, u_{{max}}\right),
\]
where $\alpha_t \in [0,1]$ is an optional engagement gate.  A later consolidation step removes the residual machinery by training a new cortex to imitate the final action $u_t$ directly.

\begin{{figure}}[t]
\centering
\includegraphics[width=\linewidth]{{Figures/RNNematode-Figures.pdf}}
\caption{{\textbf{{Teacher-guided residual control and main results.}}  A, a perturbation-trained teacher supplies a corrective target for a cerebellar residual.  B, in Humanoid-v4, residual ON vs OFF evaluation with the same checkpoint reduces fall AUC across pushes, sensor corruption, and slips (N=20).  C, the same comparison improves return AUC.  D, cross-body results are suggestive of a morphology effect: contact-rich bodies benefit strongly, while Hopper remains a boundary condition.}}
\end{{figure}}

\section*{{Results}}
\textbf{{RL-only correction was not enough.}}  We first tested spinal gain gating, residual correction trained only by PPO, curriculum perturbations, basal-ganglia-like engagement gates, and stability auxiliary terms.  These variants were useful diagnostics, but none gave a reliable causal reduction in fall AUC.  Thus, the circuit diagram alone was not the main explanation.  The key variable was whether the module received enough information to learn a useful correction at the right time.

\textbf{{Teacher-guided residuals improved survival.}}  The teacher-guided residual was tested causally: the same checkpoint and the same perturbation schedule were evaluated with the residual enabled or disabled.  In the N=20 Humanoid campaign, fall AUC decreased for push ({fall_ci_push}), sensor ({fall_ci_sensor}), and slip ({fall_ci_slip}) perturbations, where negative numbers mean fewer falls.  Return AUC increased for push ({ret_ci_push}), sensor ({ret_ci_sensor}), and slip ({ret_ci_slip}).  Perturbation sanity checks verified that pushes, friction changes, and sensor corruption were actually applied, not only logged.

\textbf{{Teacher quality mattered.}}  A strong teacher produced stabilizing residuals.  A deliberately weak teacher produced residuals that could become harmful.  This argues against a simple capacity explanation: the student learned a direction of correction from the teacher, and a bad teacher could teach the wrong direction.

\textbf{{Corrections could be consolidated.}}  We trained a cortex-only policy to imitate the final action of the residual controller.  This consolidated policy no longer used an online cerebellar residual, but it retained most of the fall reduction in Humanoid and generalized under a long-push schedule.  This suggests that the residual pathway can act as a training scaffold: useful during learning, but not always necessary at inference.

\section*{{Exploratory morphology analysis}}
The cross-body pattern gives a useful intuition, but it should not be read as an evolutionary result.  Bodies with more actuators and richer contacts create more ways to nearly fall.  In those bodies, a separate corrective pathway may be valuable because the nominal policy cannot cover every recovery case cleanly.  Ant and Humanoid showed strong fall reductions, Walker2d also replicated, and Hopper exposed a stability--performance tradeoff.  This supports a modest morphology-dependent control hypothesis: layered corrections may become more useful as the body creates more recovery states for the controller to handle.

\section*{{Methods in brief}}
Experiments used BrainCAD with MuJoCo locomotion environments \citep{{todorov2012mujoco,brockman2016openai}}.  ReflexBench applied external pushes, friction reductions, and observation corruption.  Fall AUC was computed as the area under the fall-probability curve across the predefined perturbation-severity grid (Humanoid: push magnitudes 0--1 crossed with duration, slip severities 0--1.25 crossed with patch settings, and sensor dropout bursts 0--0.4).  Return AUC was computed analogously from mean return across the same severity grid.  Curves were computed per seed before paired ON--OFF deltas were summarized with bootstrap confidence intervals.  Lower fall AUC and recovery AUC are better, while higher return AUC is better.  Source notebooks and validation summaries are included in the micropublication package.

\section*{{Data and code availability}}
Code, notebooks, figures, validation files, and video indices are packaged with this submission.  The public repository is available at https://github.com/andrestrocyte/rnnematode-micropublication.  The original implementation uses the BrainCAD experiment structure, including circuit templates, MuJoCo wrappers, evaluation scripts, and video export.

\section*{{Acknowledgments}}
We thank Raymond Chua for senior mentorship, scientific guidance, and feedback on motor-control framing.  We also acknowledge the BrainCAD/NCAP software infrastructure used for circuit templates, MuJoCo wrappers, evaluation, and video export.

\bibliographystyle{{plainnat}}
\bibliography{{references}}
\end{{document}}
"""
    (PKG / "RNNematode-Micropublication.tex").write_text(micro)

    report = rf"""\documentclass[11pt]{{article}}
\usepackage[margin=0.86in]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{amsmath,amssymb}}
\usepackage{{booktabs}}
\usepackage{{url}}
\usepackage[numbers,sort&compress]{{natbib}}
\usepackage{{hyperref}}
\hypersetup{{colorlinks=true,linkcolor=black,citecolor=black,urlcolor=blue}}
\setlength{{\parskip}}{{0.55em}}
\setlength{{\parindent}}{{0pt}}
\title{{Technical report: teacher-guided corrective residuals in BrainCAD}}
\author{{Andr\'es de Vicente, Renee Vieira, and Charlie Hou}}
\date{{Neuromatch Impact Scholars, Team RNNematode, 2026}}

\begin{{document}}
\maketitle

\section{{Project overview}}
The original goal was to implement a sensory-cerebellar NCAP-like experiment in the BrainCAD locomotion stack.  The main result became more specific: adding a biologically inspired module was not enough by itself.  The learning signal determined whether the module became a real correction or another weak policy head.  PPO-only spinal and residual circuits did not reliably learn rapid recovery.  Teacher-guided residual imitation did.  The method is intentionally close to residual imitation / policy distillation; the scientific point is that this structured teacher signal was necessary for the biologically inspired corrective architecture to become useful.

\section{{ReflexBench perturbation protocol}}
ReflexBench perturbs the agent during evaluation with three families of events:
\begin{{align}}
F_t &= s_F F_0 \mathbf{{1}}[t_0 \le t < t_0 + D_F] && \text{{external push}},\\
\mu_t &= \mu_0 (1 - s_\mu) && \text{{slip / lower friction}},\\
\tilde{{o}}_t &= M_t \odot o_t + \epsilon_t && \text{{sensor corruption}}.
\end{{align}}
Here $s_F$ and $s_\mu$ are severity values, $D_F$ is push duration, $M_t$ is a dropout mask, and $\epsilon_t$ is noise.  We verified that the perturbations were real by logging applied force magnitude, friction scale, and clean-versus-corrupted observation differences.  Control episodes had zero event rates and zero observation corruption.

\section{{Policies and learning objectives}}
\subsection{{Cortex and teacher}}
The cortex is a stochastic actor-critic policy trained by PPO:
\[
\max_\theta \; \mathbb{{E}}_t \left[\min(r_t(\theta) \hat{{A}}_t,
\mathrm{{clip}}(r_t(\theta), 1-\epsilon, 1+\epsilon)\hat{{A}}_t)\right],
\]
with a value loss and entropy term as in standard PPO \citep{{schulman2017ppo}}.  The teacher has the same basic role as a cortex policy but is trained under domain-randomized perturbations.  It is not used at test time in the residual student, except when evaluating the teacher as a baseline.

\subsection{{Cerebellar residual}}
The cerebellar module is bounded:
\[
\Delta u_\psi(o_t,u_t^{{ctx}}) =
\Delta u_{{max}} \tanh f_\psi([o_t,u_t^{{ctx}}]).
\]
The optional gate is
\[
\alpha_t = \sigma(g_\eta(o_t,u_t^{{ctx}},\|\Delta u_t\|)).
\]
The executed action is
\[
u_t = \mathrm{{clip}}(u_t^{{ctx}} + \alpha_t \Delta u_t, u_{{min}}, u_{{max}}).
\]
The supervised residual target is:
\[
\Delta u_t^* = u_t^{{teacher}} - u_t^{{ctx}}.
\]
For event and recovery masks $m_t$, training minimizes:
\[
\mathcal{{L}}_{{cb}} =
\frac{{\sum_t m_t \|\Delta u_\psi(o_t,u_t^{{ctx}}) - \Delta u_t^*\|_2^2}}
{{\sum_t m_t + \epsilon}} + \lambda \|\psi\|_2^2.
\]
This is the central difference between the successful model and the RL-only residual: the residual sees a dense vector target at exactly the times when recovery matters.

\subsection{{Structural consolidation}}
Consolidation trains a new cortex to imitate the final residual action:
\[
u_t^{{target}} = \mathrm{{clip}}(u_t^{{ctx}} + \alpha_t \Delta u_t, u_{{min}}, u_{{max}}),
\]
\[
\mathcal{{L}}_{{cons}} =
\frac{{1}}{{N}}\sum_t w_t \|\pi_{{\phi'}}(o_t) - u_t^{{target}}\|_2^2.
\]
The consolidated policy is cortex-only at inference.  It tests whether the correction can become part of the feedforward motor command, instead of requiring an extra residual module forever.  This consolidation stage is also a useful guard against over-interpreting the residual module itself: if the correction can be folded into cortex, then the important ingredient is the training signal and target structure, not permanent extra inference-time machinery.

\section{{Statistics and sign conventions}}
For each perturbation family, we evaluated a grid of severities and summarized the curve by area under the curve (AUC).  In the default Humanoid predefined severity sweep, push magnitudes ranged from 0 to 1 and were crossed with push duration, slip severity ranged from 0 to 1.25 and was crossed with patch width/duration, and sensor dropout bursts ranged from 0 to 0.4.  For return,
\[
\mathrm{{AUC}}_R = \int R(s)\,ds,
\]
so higher values are better.  For falls,
\[
\mathrm{{AUC}}_F = \int P(\mathrm{{fall}}\mid s)\,ds,
\]
so lower values are better.  The causal residual effect is always a paired comparison:
\[
\Delta_F = \mathrm{{AUC}}_F(\mathrm{{ON}}) - \mathrm{{AUC}}_F(\mathrm{{OFF}}),
\]
using the same checkpoint and the same perturbation schedule.  A negative $\Delta_F$ therefore means the residual prevented falls.  The same paired definition was used for return AUC.  Confidence intervals in the saved tables are bootstrap intervals over seeds unless otherwise noted.

\section{{Main Humanoid results}}
Table~\ref{{tab:humanoid}} summarizes the N=20 Humanoid campaign.  Negative fall deltas mean fewer falls under the same severity sweep.  The important point is that the fall-AUC confidence interval excludes zero for push, slip, and sensor corruption, not only that the average looks favorable.

\begin{{table}}[h]
\centering
\small
\input{{../tables/humanoid_key_results.tex}}
\caption{{Humanoid default predefined severity sweep, N=20.}}
\label{{tab:humanoid}}
\end{{table}}

\begin{{figure}}[h]
\centering
\includegraphics[width=\linewidth]{{../Figures/RNNematode-Figures.pdf}}
\caption{{Main micropublication figure.}}
\end{{figure}}

\section{{Negative result: RL-only corrective subcircuits}}
The failure ladder matters because it rules out a simple architectural explanation.  The useful ingredient was not the name of the module.  SC-NCAP gain gating, PPO-trained residuals, curriculum residuals, BG-like gates, and stability auxiliary variants did not produce consistent causal robustness improvements.  These results suggest that sparse reward was too indirect for learning a small, fast corrective residual.  Conversely, the successful method should not be presented as a new distillation algorithm; it is a biologically organized use of a known supervised residual-learning idea.

The failed variants also differed mechanistically.  In SC-NCAP, prediction error modulated sensory gain before the spinal interface.  In the RL-only residual, a bounded torque correction was available but had to be discovered from sparse return.  In the stability-auxiliary variants, the residual received extra pressure toward uprightness during perturbation windows, but the correction still did not become consistently useful.  These attempts became useful controls: they show that the successful effect is not a generic consequence of adding more modules.

\section{{Perturbation sanity}}
We also checked that ReflexBench was not only logging intended perturbations.  Table~\ref{{tab:sanity}} reports simple on/off contrasts from the perturbation sanity runs.  Push values are applied force differences, slip values are the drop in friction scale, and sensor values are clean-versus-corrupted observation differences, each summarized in the native scale of the environment and then reported compactly.  Control episodes had zero event flags.

\begin{{table}}[h]
\centering
\small
\input{{../tables/perturbation_sanity_compact.tex}}
\caption{{Compact perturbation sanity checks.  Nonzero push/slip/sensor contrasts confirm that the perturbations were actually applied.}}
\label{{tab:sanity}}
\end{{table}}

\section{{Teacher quality and safety}}
Teacher degradation provided a useful counterfactual.  Students trained from the full teacher improved fall robustness, while students trained from weak teacher checkpoints could become harmful.  In the weak-teacher runs, larger residual corrections tended to predict worse stability outcomes in several windows.  Thus, the residual pathway can inherit useful corrections, but it can also inherit a teacher's mistakes.

\begin{{table}}[h]
\centering
\small
\input{{../tables/teacher_quality_short.tex}}
\caption{{Teacher-quality replication.  Negative fall deltas are helpful; positive fall deltas are harmful.}}
\label{{tab:teacher}}
\end{{table}}

This threshold-like pattern helps interpret the result.  If every teacher produced the same student benefit, the result would look like a generic capacity increase.  Instead, the sign of the learned correction depends on teacher competence.  This is consistent with the residual learning a corrective vector field rather than simply smoothing the action.

\section{{Structural consolidation}}
The consolidation result asks whether the residual is only useful as an extra online module.  We collected trajectories from the residual-ON student and trained a new cortex policy to match the actually executed action.  The consolidation target is:
\[
u_t^{{target}} = u_t^{{final}}.
\]
This is stricter than copying the teacher, because $u_t^{{final}}$ includes the clipped combination of cortex, residual, and optional gate.  In Humanoid, the consolidated cortex-only policy closed most of the baseline-to-imitation fall gap on the default schedule and also generalized under the long-push schedule.  This gives the residual a training role: the correction first appears as a separate pathway, then can be folded back into the main motor command.

\section{{Cross-environment and morphology-dependent control demands}}
\begin{{table}}[h]
\centering
\small
\input{{../tables/cross_environment_summary.tex}}
\caption{{Cross-environment summary.  Humanoid rows use the N=20 default-schedule result; other environments use the saved cross-environment replication summaries.}}
\end{{table}}

The morphology analysis should be treated cautiously.  Hopper, Walker2d, Ant, and Humanoid are not an evolutionary tree, and four simulated bodies cannot establish a scaling law.  Still, the pattern is useful as a control-demand analysis.  More contact-rich bodies create more transient failure modes; this is exactly where layered corrective control should be useful.  Ant and Humanoid show strong fall reductions.  Hopper is a boundary condition: its underactuated morphology makes conservative corrections able to reduce some falls while hurting return.

\begin{{table}}[h]
\centering
\small
\input{{../tables/morphology_short.tex}}
\caption{{Morphology table used for the exploratory scaling plot.  Values may differ from Table~\ref{{tab:humanoid}} because this plot uses the cross-environment matched summary rather than the full Humanoid N=20 default-schedule summary.  The regression confidence intervals are wide; this table is best read as motivation for future work rather than a final scaling law.}}
\label{{tab:morphology}}
\end{{table}}

\section{{Additional checks}}
The report includes the most important controls in the main text: RL-only failures, perturbation sanity checks, teacher-quality degradation, and cross-environment summaries.  The figure below collects these controls in one place so the direction of each check can be inspected visually.

\begin{{figure}}[h]
\centering
\includegraphics[width=\linewidth]{{../Figures/RNNematode-Supplementary-Figures.pdf}}
\caption{{Supplementary checks: RL-only failure ladder, teacher-quality threshold, perturbation sanity, and cross-environment tradeoffs.  In the failure-ladder panel, positive fall-AUC reduction values indicate improvement over the MLP baseline, while negative values indicate worse fall robustness.}}
\end{{figure}}

\section{{Limitations}}
This project does not prove that the biological cerebellum implements our exact residual loss.  The better claim is that a cerebellar-inspired supervised correction pathway is a useful engineering abstraction for these locomotion tasks.  Modern privileged-adaptation baselines such as RMA remain important comparators.  Compute fairness is also subtle: the teacher has its own perturbation-trained experience, while the student learns from that experience in supervised form.  We therefore frame the result as a learning-signal result rather than a claim that this architecture dominates all adaptation methods.

\section{{Where the code lives}}
Core implementation files:
\begin{{itemize}}
\item \texttt{{paper/experiments/sc\_ncap/circuits/cerebellum.py}}: bounded residual module.
\item \texttt{{paper/experiments/sc\_ncap/policies/cortex\_residual\_policy.py}}: cortex plus residual action composition.
\item \texttt{{paper/experiments/sc\_ncap/scripts/train\_cerebellum\_imitation.py}}: supervised residual imitation.
\item \texttt{{paper/experiments/sc\_ncap/scripts/train\_consolidated\_cortex.py}}: structural consolidation.
\end{{itemize}}

\section*{{Acknowledgments}}
We thank Raymond Chua for senior mentorship, scientific guidance, and feedback on motor-control framing.  We also acknowledge the BrainCAD/NCAP software infrastructure used for circuit templates, MuJoCo wrappers, evaluation, and video export.

\bibliographystyle{{plainnat}}
\bibliography{{../references}}
\end{{document}}
"""
    (REPORT_DIR / "RNNematode-TechnicalReport.tex").write_text(report)


def build_readme(data: Dict[str, object]) -> None:
    videos = []
    if P.video_index.exists():
        vdf = pd.read_csv(P.video_index)
        videos = [_relativize_known_paths(str(p)) for p in vdf["curated_path"].head(12)]
    readme = [
        "# RNNematode micropublication package",
        "",
        "This folder contains the Neuromatch-style micropublication envelope for the BrainCAD NCAP project.",
        "",
        "## Main claim",
        "",
        "RL-only corrective subcircuits did not reliably learn fast recovery under PPO. Teacher-guided cerebellar residual imitation did: it reduced fall AUC in Humanoid across 20 seeds, replicated in Walker2d and Ant, exposed Hopper as a boundary condition, and could be consolidated into cortex-only execution.",
        "",
        "## Build",
        "",
        "```bash",
        "cd path/to/rnnematode-micropublication",
        "./build.sh",
        "```",
        "",
        "## Key outputs",
        "",
        "- `RNNematode-Micropublication.pdf`: compact micropublication.",
        "- `report/RNNematode-TechnicalReport.pdf`: longer report with equations and more data.",
        "- `Figures/RNNematode-Figures.svg`: main figure sheet in SVG.",
        "- `Figures/RNNematode-Supplementary-Figures.svg`: supplementary figure sheet in SVG.",
        "- `Codes/*.ipynb`: minimal documented notebooks.",
        "- `RNNematode-Contributions.xlsx`: contribution table.",
        "- `VALIDATION.md`: result and source-code sanity checks.",
        "",
        "## Representative videos",
        "",
        "The package uses the existing video index rather than copying large MP4 files. Representative examples:",
    ]
    for p in videos[:8]:
        readme.append(f"- `{p}`")
    readme += [
        "",
        "## Data provenance",
        "",
        "- Humanoid headline result: `paper/experiments/sc_ncap/results/humanoid_teacher_guided_20seed_campaign/20260421_rerun/analysis/`.",
        "- Cross-environment summaries: `paper/neurips_2026/tables/` and `paper/experiments/sc_ncap/results/*_cross_env_replication/`.",
        "- Perturbation sanity summaries: `paper/experiments/sc_ncap/results/*_perturbation_sanity_summary.json`.",
        "",
        "No training is run by the package builder.",
    ]
    (PKG / "README.md").write_text("\n".join(readme) + "\n")

    fig_index = [
        "# Figure index",
        "",
        "| Figure | File | Source data |",
        "|---|---|---|",
        "| Main micropublication figure | `Figures/RNNematode-Figures.svg` | N=20 Humanoid summaries, morphology table |",
        "| Supplementary checks | `Figures/RNNematode-Supplementary-Figures.svg` | failure ladder, teacher-quality table, perturbation sanity JSON, cross-env summary |",
        "",
        "Every figure also has `.png` and `.pdf` siblings for visual checking and LaTeX builds.",
    ]
    (PKG / "FIGURE_INDEX.md").write_text("\n".join(fig_index) + "\n")

    build = """#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python scripts/build_micropublication_assets.py
latexmk -pdf -interaction=nonstopmode RNNematode-Micropublication.tex
latexmk -c RNNematode-Micropublication.tex >/dev/null 2>&1 || true
cd report
latexmk -pdf -interaction=nonstopmode RNNematode-TechnicalReport.tex
latexmk -c RNNematode-TechnicalReport.tex >/dev/null 2>&1 || true
"""
    (PKG / "build.sh").write_text(build)
    (PKG / "build.sh").chmod(0o755)

    commands = """#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Rebuild figures, tables, LaTeX sources, PDFs, and contribution files.
./build.sh

# Execute the lightweight explanatory notebooks in-place.
for nb in Codes/*.ipynb; do
  jupyter nbconvert --to notebook --execute --inplace "$nb"
done
"""
    (PKG / "commands_session.sh").write_text(commands)
    (PKG / "commands_session.sh").chmod(0o755)


def build_literature_note() -> None:
    note = """# Literature framing used in this package

The micropublication deliberately cites fewer papers than the NeurIPS draft.  The goal is not to survey all robust locomotion, but to place the result in three anchors:

1. Cerebellar internal models and error-based motor learning.
2. PPO / MuJoCo as the technical training substrate.
3. Modern robust locomotion and residual/consolidation work as nearby machine-learning context.

BrainCAD is cited as the software substrate because the project uses its experiment structure, circuit templates, MuJoCo wrappers, analysis scripts, and video export pipeline.
"""
    (PKG / "LITERATURE_NOTE.md").write_text(note)


def main() -> None:
    _mkdirs()
    data = build_derived_tables()
    build_figures(data)
    build_contributions()
    build_notebooks()
    _copy_reference_bib()
    build_tex(data)
    build_readme(data)
    build_literature_note()
    build_myst_submission()
    build_submission_checklist()
    build_code_readme_and_zip()
    print(f"Wrote micropublication package to {PKG}")


if __name__ == "__main__":
    main()
