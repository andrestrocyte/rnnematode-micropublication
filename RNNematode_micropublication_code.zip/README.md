# RNNematode micropublication package

This folder contains the Neuromatch-style micropublication envelope for the BrainCAD NCAP project.

## Main claim

RL-only corrective subcircuits did not reliably learn fast recovery under PPO. Teacher-guided cerebellar residual imitation did: it reduced fall AUC in Humanoid across 20 seeds, replicated in Walker2d and Ant, exposed Hopper as a boundary condition, and could be consolidated into cortex-only execution.

## Build

```bash
cd path/to/rnnematode-micropublication
./build.sh
```

## Key outputs

- `RNNematode-Micropublication.pdf`: compact micropublication.
- `report/RNNematode-TechnicalReport.pdf`: longer report with equations and more data.
- `Figures/RNNematode-Figures.svg`: main figure sheet in SVG.
- `Figures/RNNematode-Supplementary-Figures.svg`: supplementary figure sheet in SVG.
- `Codes/*.ipynb`: minimal documented notebooks.
- `RNNematode-Contributions.xlsx`: contribution table.
- `VALIDATION.md`: result and source-code sanity checks.

## Representative videos

The package uses the existing video index rather than copying large MP4 files. Representative examples:
- `videos/20260422_000426/curated/humanoid/baseline_off/nominal.mp4`
- `videos/20260422_000426/curated/humanoid/baseline_off/moderate.mp4`
- `videos/20260422_000426/curated/humanoid/baseline_off/severe.mp4`
- `videos/20260422_000426/curated/humanoid/imitation_off/nominal.mp4`
- `videos/20260422_000426/curated/humanoid/imitation_off/moderate.mp4`
- `videos/20260422_000426/curated/humanoid/imitation_off/severe.mp4`
- `videos/20260422_000426/curated/humanoid/imitation_on/nominal.mp4`
- `videos/20260422_000426/curated/humanoid/imitation_on/moderate.mp4`

## Data provenance

- Humanoid headline result: `paper/experiments/sc_ncap/results/humanoid_teacher_guided_20seed_campaign/20260421_rerun/analysis/`.
- Cross-environment summaries: `paper/neurips_2026/tables/` and `paper/experiments/sc_ncap/results/*_cross_env_replication/`.
- Perturbation sanity summaries: `paper/experiments/sc_ncap/results/*_perturbation_sanity_summary.json`.

No training is run by the package builder.
